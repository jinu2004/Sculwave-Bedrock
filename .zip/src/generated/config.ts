export const BackendConfig = {
    "serverUrl": "https://sculwave.com",
    "activationKey": "",
    "serverName": "Bedrock Server"
} as const;
