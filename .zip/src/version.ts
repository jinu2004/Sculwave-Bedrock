export const versionInfo = {
  version: "1.1.0",
  build: "261102.0455" // The script will automatically overwrite this value
};

