export const versionInfo = {
  version: "1.1.0",
  build: "261029.2052" // The script will automatically overwrite this value
};

