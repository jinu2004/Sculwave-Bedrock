
#!/bin/bash
set -Eeuo pipefail

echo "🚀 Starting Bedrock addon deployment..."

PROJECT_DIR="/home/jinu/Documents/addon/projects/The Hollow"
SERVER_DIR="/opt/minecraft-bedrock-server"
WORLD_NAME="Bedrock level"
WORLD_DIR="$SERVER_DIR/worlds/$WORLD_NAME"
BP_SOURCE="$PROJECT_DIR/BP"
RP_SOURCE="$PROJECT_DIR/RP"
BP_WORLD="$WORLD_DIR/behavior_packs/BP"
RP_WORLD="$WORLD_DIR/resource_packs/the_hollow_rp"
SERVICE="minecraft-bedrock-server"

cd "$PROJECT_DIR"

echo "🔍 Validating project files..."
[[ -f "$PROJECT_DIR/build.js" ]] || { echo "ERROR: build.js not found"; exit 1; }
[[ -f "$BP_SOURCE/manifest.json" ]] || { echo "ERROR: BP/manifest.json not found"; exit 1; }
[[ -d "$RP_SOURCE" ]] || { echo "ERROR: RP directory not found"; exit 1; }
[[ -d "$WORLD_DIR/behavior_packs/BP" ]] || { echo "ERROR: Active behavior pack not found at $BP_WORLD"; exit 1; }

echo "🔍 Validating source manifest..."
node --input-type=module -e '
import fs from "node:fs";
const m = JSON.parse(fs.readFileSync("BP/manifest.json", "utf8"));
const d = m.dependencies?.find(x => x.module_name === "@minecraft/server-net");
if (!d) throw Error("@minecraft/server-net dependency missing");
if (d.version !== "1.0.0-beta") throw Error(`Expected server-net 1.0.0-beta, got ${d.version}`);
console.log("server-net:", d.version);
'

echo "📦 Building project..."
node "$PROJECT_DIR/build.js"

echo "⚡ Compiling TypeScript..."
npx tsc

[[ -d "$PROJECT_DIR/build" ]] || { echo "ERROR: build directory not found"; exit 1; }
[[ -f "$PROJECT_DIR/build/main.js" ]] || { echo "ERROR: build/main.js not found"; exit 1; }

echo "📂 Preparing compiled scripts..."
rm -rf "$BP_SOURCE/scripts"
mkdir -p "$BP_SOURCE/scripts"
cp -a "$PROJECT_DIR/build/." "$BP_SOURCE/scripts/"

echo "🔍 Validating generated manifest..."
node --input-type=module -e '
import fs from "node:fs";
const m = JSON.parse(fs.readFileSync("BP/manifest.json", "utf8"));
if (!m.modules?.some(x => x.type === "script" && x.entry === "scripts/main.js")) throw Error("Script entry must be scripts/main.js");
'

echo "🛑 Stopping Minecraft server..."
sudo systemctl stop "$SERVICE"

restart_server() {
  echo "🔄 Starting Minecraft server..."
  sudo systemctl start "$SERVICE"
}
trap restart_server EXIT

echo "📦 Deploying Behavior Pack..."
sudo mkdir -p "$BP_WORLD"
sudo cp -a "$BP_SOURCE/." "$BP_WORLD/"

echo "📦 Deploying Resource Pack..."
sudo mkdir -p "$RP_WORLD"
sudo cp -a "$RP_SOURCE/." "$RP_WORLD/"

echo "🔒 Fixing ownership..."
sudo chown -R minecraft-bedrock:minecraft-bedrock "$BP_WORLD" "$RP_WORLD"

echo "🔍 Verifying deployed manifest..."
sudo node --input-type=module -e '
import fs from "node:fs";
const p = "/opt/minecraft-bedrock-server/worlds/Bedrock level/behavior_packs/BP/manifest.json";
const m = JSON.parse(fs.readFileSync(p, "utf8"));
const d = m.dependencies?.find(x => x.module_name === "@minecraft/server-net");
if (d?.version !== "1.0.0-beta") throw Error(`Deployed manifest has unexpected server-net version: ${d?.version}`);
console.log("Deployed server-net:", d.version);
'

echo "🧹 Clearing script storage if present..."
sudo rm -rf "$WORLD_DIR/script_storage" "$WORLD_DIR/internalStorage"

echo "📋 Deployed behavior pack:"
sudo ls -la "$BP_WORLD"

echo "📋 Deployed resource pack:"
sudo ls -la "$RP_WORLD"

echo "✅ Deployment steps completed. Server will restart automatically."
